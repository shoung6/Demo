#BvdVideo
[H5打造属于自己的视频播放器（JS篇1）](https://segmentfault.com/a/1190000006492676)
[H5打造属于自己的视频播放器（JS篇2）](https://segmentfault.com/a/1190000006604046)